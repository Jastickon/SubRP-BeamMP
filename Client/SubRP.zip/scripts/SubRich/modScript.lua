load("SubRich")
registerCoreModule("SubRich")