load("SubRPHud")
registerCoreModule("SubRPHud")